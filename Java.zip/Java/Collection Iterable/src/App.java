
public class App {

	public static void main(String[] args) {
		IterableClass IC = new IterableClass();
		
		for(String str:IC)
			System.out.println(str.length());

	}

}
