import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class IterableClass implements Iterable<String> {

	private List<String> list = new LinkedList<>();

	private class IteratorClass implements Iterator<String> {
		private int index = 0;

		@Override
		public boolean hasNext() {
			return index < list.size();
		}

		@Override
		public String next() {
			StringBuilder sb = new StringBuilder();
			try {
				URL url = new URL(list.get(index));
				BufferedReader br = new BufferedReader(new InputStreamReader(url.openStream()));
				String line = null;
				while (br.readLine() != null) {
					sb.append(line);
					sb.append("\n");
				}
				br.close();

			} catch (Exception e) {
				e.printStackTrace();
			}
			index++;
			return sb.toString();
		}

		@Override
		public void remove() {
			list.remove(index);
		}
	}

	public IterableClass() {
		list.add("http://geeksforgeeks");
//		list.add("two");
//		list.add("three");
	}

	@Override
	public Iterator<String> iterator() {
		return new IteratorClass();
	}

}
