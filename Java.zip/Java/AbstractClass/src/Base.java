
public abstract class Base {
	private int id;
	
	public void get() {
		System.out.println("Base get method");
	}
	
	public abstract void getMethod();

}
