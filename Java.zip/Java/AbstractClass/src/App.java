
public class App {

	public static void main(String[] args) {
		Child c = new Child();
		c.getMethod();
		c.get();

	}

}
