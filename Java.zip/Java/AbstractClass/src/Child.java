
public class Child extends Base{

	@Override
	public void getMethod() {
		System.out.println("Child getMethod");
		
	}

}
