interface MathOperation {
	int operate(int a, int b);
}

interface Greeting {
	void sayMessage(String message);
}

public class App {
	final static String msg = "world";

	public static void main(String[] args) {
		App app = new App();
		MathOperation add = (int a, int b) -> a + b;
		MathOperation sub = (a, b) -> a - b;
		System.out.println("Subtraction: " + sub.operate(20, 10));
		System.out.println("Addition: " + add.operate(10, 20));

		Greeting G = message -> System.out.println("1: " + message + msg);
		G.sayMessage("Hello ");

	}
}