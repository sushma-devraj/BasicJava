
public class App {

	public static void main(String[] args) {
		int value = 8;
		App app = new App();
		
		System.out.println("value 1: " + value);
		app.show(value);
		System.out.println("value 4: " + value);
		
		Person person = new Person("Bob");
		System.out.println("Person 1: " + person);
		app.show(person);
		System.out.println("Person 4: " + person);
	}

	public void show(int value) {
		System.out.println("value 2: " + value);
		value=10;
		System.out.println("value 3: " + value);
		
	}
	public void show(Person person) {
		System.out.println("Person 2: " + person);
		person = new Person("Sob");
		System.out.println("Person 3: " + person);
	}
	

}
