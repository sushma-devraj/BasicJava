import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;

public class WriteObject implements Serializable {

	public static void main(String[] args) {

		App[] app = { new App(3, "Three"), new App(4, "Four"), new App(5, "Five") };
		
		ArrayList<App> ap = new ArrayList<App>(Arrays.asList(app));

		try (FileOutputStream fs = new FileOutputStream("Sample.txt")) {
			ObjectOutputStream os = new ObjectOutputStream(fs);
			os.writeObject(app);
			os.writeObject(ap);
			os.writeInt(ap.size());
			os.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
