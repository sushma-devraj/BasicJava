import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.util.ArrayList;

public class ReadObject implements Serializable {

	public static void main(String[] args) {
		try (FileInputStream fi = new FileInputStream("Sample.txt")) {
			ObjectInputStream os = new ObjectInputStream(fi);
			App[] app = (App[]) os.readObject();

			ArrayList<App> ap = (ArrayList<App>) os.readObject();
			for (App appp : app)
				System.out.println(appp);

			for (App a : ap)
				System.out.println(a);
			os.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();

		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

	}

}
