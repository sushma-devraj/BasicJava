
public class ArrayString {

	public static void main(String[] args) {
		String[] str1=new String[3];
		for(int i=0; i<str1.length; i++)
			str1[i]="string"+i;
		for(int i=0; i<str1.length; i++)
			System.out.println(str1[i]);

		String[] str2={"One","Two","Three"};
		for(int i=0; i<str2.length; i++)
			System.out.println(str2[i]);

	}

}
