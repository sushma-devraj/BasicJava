
public class AgeNotFoundException extends Exception{
	AgeNotFoundException(String s){
		super(s);
	}
}
