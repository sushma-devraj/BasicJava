
public class Person {
	private static int age=18;
	public static void getAge() throws AgeNotFoundException{
		if(age <=18) {
			throw new AgeNotFoundException("Age not found");
		}
	}

	public static void main(String[] args) {
		try {
			Person.getAge();
		}
		catch(AgeNotFoundException e) {
			System.out.println(e);
		}

	}

}
