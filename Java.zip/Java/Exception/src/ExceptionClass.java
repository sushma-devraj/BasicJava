
public class ExceptionClass {

	public void handle() throws ArrayIndexOutOfBoundsException{
		int[] arr = new int[5];
		for (int i = 0; i < arr.length + 1; i++)
			System.out.println(arr[i]);
	}

	public static void main(String[] args) {
		ExceptionClass EC = new ExceptionClass();
		try {
			EC.handle();
		}catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("ArrayIndexOutOfBoundsException Caught!!!");
		}
		catch (Exception e) {
			System.out.println("Exception Caught!!!");
		}
		finally{
		System.out.println("Finally!!!");
		}
		System.out.println("Hello");
	}
}
