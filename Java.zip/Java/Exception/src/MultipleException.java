
public class MultipleException {
	public void handle() throws ArrayIndexOutOfBoundsException, ArithmeticException {
		int[] arr = new int[5];
		for (int i = 0; i < arr.length + 1; i++) {
			System.out.println(arr[i]/1);
		}
	}

	public static void main(String[] args) {
		MultipleException EC = new MultipleException();
		try {
		EC.handle();
		}
		catch(ArithmeticException e){
			System.out.println("Caught Arithmetic Exception");
		}
		catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("Caught ArrayIndexOutOfBoundsException Exception");
		}
		catch(Exception e) {
			System.out.println("Caught Exception");
		}
		System.out.println("Hello");
	}
}
