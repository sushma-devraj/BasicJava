class Person5{
	public String name;
	public static final int ID = 1;
	public static int age;
	public static int count=0;
	
	public Person5(String name) {
		this.name=name;
		count++;
	}
	public static void setName(int personAge) {
		age=personAge;
	}
	public void getPerson() {
		System.out.println(ID+" "+name+" "+age+" "+count);
	}
}
public class StaticFinal {
	public static void main(String[] args) {
		Person5 p = new Person5("Joe");
		Person5.setName(30);
		p.getPerson();
	}

}
