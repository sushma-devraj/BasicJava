class Person1{
	String name;
	int age;
	public String getName(){
		return name;
	}
	public int getAge(){
		return age;
	}
}

public class GetterReturn {

	public static void main(String[] args) {
		Person1 p1 = new Person1();
		p1.name="Joe";
		p1.age=34;
		System.out.println(p1.getName());
		System.out.println(p1.getAge());

	}

}
