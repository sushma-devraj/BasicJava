import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;

public class SetClass {

	private static void sets(Set<String> set) {
		set.add("one");
		set.add("one");
		set.add("three");
		set.add("two");
		set.add("four");

		for (String str : set)
			System.out.println(str);
		System.out.println("Size " + set.size());
		System.out.println("Contains " + set.contains("one"));
		System.out.println("Is empty " + set.isEmpty());
		//System.out.println("Remove " + set.remove("one"));
		for (String str : set)
			System.out.println(str);

		System.out.println(" ");

	}

	public static void main(String[] args) {
		Set<String> hashSet = new HashSet<>();
		Set<String> linkedHashSet = new LinkedHashSet<>();

		//sets(hashSet);
		//sets(linkedHashSet);
		
		Set<String> hashSet1 = new HashSet<>();
		hashSet1.add("oneApple");
		hashSet1.add("oneApple");
		hashSet1.add("threeMango");

		Set<String> linkedHashSet1 = new LinkedHashSet<>();
		linkedHashSet1.add("twoBanana");
		linkedHashSet1.add("fourOrange");
		linkedHashSet1.add("oneApple");

		Set<String> treeSet1 = new TreeSet<>(hashSet1);
		treeSet1.retainAll(linkedHashSet1);
		System.out.println("RetainAll matched Treeset1 of hashSet1 and linkedHashSet1");
		System.out.println(treeSet1);
		
		Set<String> treeSet2 = new TreeSet<>(hashSet1);
		treeSet1.removeAll(linkedHashSet1);
		System.out.println("RemoveAll linkedHashSet1 from hashset1");
		System.out.println(treeSet2);

	}

}
