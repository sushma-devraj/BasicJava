import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class IteratorClass {

	public static void main(String[] args) {
		List<String> list = new LinkedList<>();
		list.add("one");
		list.add("two");
		list.add("three");
		
		list.remove("one");

		Iterator<String> it = list.iterator();

		while (it.hasNext()) {

			if (it.next().equals("two"))
				System.out.println(it.next());

		}
		System.out.println(" ");
		for (String lst : list) {
			System.out.println(lst);
		}
	}

}
