import java.util.HashMap;
import java.util.Map;

public class HashMapClass {

	public static void main(String[] args) {
		//No duplicates and ordered output
		Map<Integer, String> map = new HashMap<>();
		map.put(1,"one");
		map.put(3, "three");
		map.put(3, "three");
		map.put(2, "two");
		
		System.out.println(map.get(2));
		for(Map.Entry<Integer, String> entry: map.entrySet()) {
			System.out.println(entry.getKey() +" "+entry.getValue());
			//or System.out.println(entry);
		}
	}

}
