import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

class Person{
	private static int id;
	private static String name;
	public Person(int id, String name) {
		this.id=id;
		this.name=name;
	}
	@Override
	public String toString() {
		return "name: "+name+" "+"id: "+id;
	}
}
public class ObjectMapSet {
	public static void main(String[] args) {
		Person p1 = new Person(100,"One Hundred");
		Person p2 = new Person(300,"Three Hundred");
		Person p3 = new Person(200,"Two Hundred");
		
		Set<Person> set = new LinkedHashSet<>();
		set.add(p1);
		set.add(p2);
		set.add(p3);
		System.out.println(set);
		
		Map<Person, Integer> map = new LinkedHashMap<>();
		map.put(p1, 1);
		map.put(p2, 2);
		map.put(p3, 3);
		for(Person key:map.keySet())
			System.out.println(map.get(key));

	}

}
