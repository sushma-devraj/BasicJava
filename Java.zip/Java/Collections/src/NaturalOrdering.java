import java.util.Collection;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;

class Animal implements Comparable<Animal> {
	private String name;

	Animal(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "Name: " + name;
	}

//	@Override
//	public int compareTo(Animal o) {
//		return -name.compareTo(o.name);
//	}

	@Override
	public int compareTo(Animal o) {
		int len1 = name.length();
		int len2 = o.name.length();
		System.out.println(name.length());
		System.out.println(o.name.length());
		if (len1 > len2)
			return 1;
		else if (len1 < len2)
			return -1;
		else
			//return 0; // remove same length String in set 
			return name.compareTo(o.name);
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Animal other = (Animal) obj;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}
}

public class NaturalOrdering {

	public static void main(String[] args) {
		List<Animal> list = new LinkedList<>();
		SortedSet<Animal> set = new TreeSet<>();

		addElements(list);
		addElements(set);

		Collections.sort(list);

		System.out.println("List: ");
		showElements(list);
		System.out.println(" ");
		System.out.println("Set: ");
		showElements(set);

	}

	private static void showElements(Collection<Animal> col) {
		for (Animal str : col)
			System.out.println(str);
	}

	private static void addElements(Collection<Animal> col) {
		col.add(new Animal("one"));
		col.add(new Animal("two"));
		col.add(new Animal("zero"));
		col.add(new Animal("three"));
	}

}
