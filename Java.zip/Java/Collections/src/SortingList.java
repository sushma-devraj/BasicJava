import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

class Employee {
	private int id;
	private String name;

	Employee(int id, String name) {
		this.id = id;
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "Name: " + name + " " + "id: " + id;
	}
}

class StringLengthComparator implements Comparator<String> {

	@Override
	public int compare(String o1, String o2) {
		int len1 = o1.length();
		int len2 = o2.length();
		if (len1 > len2)
			return 1;
		else if (len1 < len2)
			return -1;
		return 0;
	}

}

class AlphabeticalComparator implements Comparator<String> {

	@Override
	public int compare(String o1, String o2) {
		return o1.compareTo(o2);
	}

}

class ReverseComparator implements Comparator<String> {

	@Override
	public int compare(String o1, String o2) {
		return -o1.compareTo(o2);
	}

}

public class SortingList {

	public static void main(String[] args) {
		List<String> lst = new ArrayList<>();
		lst.add("oneeeeeeee");
		lst.add("zero");
		lst.add("two");

		for (String list : lst)
			System.out.println(list);

		Collections.sort(lst, new StringLengthComparator());

		System.out.println(" ");
		for (String list : lst)
			System.out.println(list);

		System.out.println("====Integer=====");
		List<Integer> lst1 = new ArrayList<>();
		lst1.add(3);
		lst1.add(2);
		lst1.add(5);

		for (Integer list : lst1)
			System.out.println(list);

		// Collections.sort(lst1); // ascending default
		// Sort Descending

		Collections.sort(lst1, new Comparator<Integer>() {

			@Override
			public int compare(Integer o1, Integer o2) {

				return -o1.compareTo(o2);
			}

		});

		System.out.println(" ");
		for (Integer list : lst1)
			System.out.println(list);

		System.out.println("=========Sort String based on length======");
		Collections.sort(lst, new StringLengthComparator());
		System.out.println(" ");
		for (String list : lst)
			System.out.println(list);

		System.out.println("=========Sort String based on Alphabet======");
		Collections.sort(lst, new AlphabeticalComparator());
		System.out.println(" ");
		for (String list : lst)
			System.out.println(list);

		System.out.println("=========Reverse sort String ======");
		Collections.sort(lst, new ReverseComparator());
		System.out.println(" ");
		for (String list : lst)
			System.out.println(list);

		List<Employee> empList = new ArrayList<>();
		empList.add(new Employee(1, "one"));
		empList.add(new Employee(2, "two"));
		empList.add(new Employee(3, "three"));
		empList.add(new Employee(1, "one"));

		// Sort based on id
		Collections.sort(empList, new Comparator<Employee>() {

			@Override
			public int compare(Employee o1, Employee o2) {
				if (o1.getId() > o2.getId())
					return 1;
				else if (o1.getId() < o2.getId())
					return -1;
				return 0;
			}
		});
		for (Employee emp : empList)
			System.out.println(emp);
		System.out.println(" ");

		// Sort based on name
		Collections.sort(empList, new Comparator<Employee>() {

			@Override
			public int compare(Employee o1, Employee o2) {
				return o1.getName().compareTo(o2.getName());
			}
		});

		for (Employee emp : empList)
			System.out.println(emp);
	}

}
