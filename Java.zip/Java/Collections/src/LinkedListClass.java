import java.util.LinkedList;
import java.util.List;

public class LinkedListClass {
	public static void addList(List<Integer> list) {
		list.add(100);
		list.add(300);
		list.add(300);
		list.add(200);
		
		list.sort(null);
		
		list.remove(1);
		
		for(Integer l:list)
			System.out.println(l);
	}

	public static void main(String[] args) {
		List<Integer> lst = new LinkedList<>();
		//List<Integer> arr = new ArrayList<>();
		addList(lst);
		

	}

}
