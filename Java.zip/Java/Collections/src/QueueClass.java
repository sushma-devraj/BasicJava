import java.util.Queue;
import java.util.concurrent.ArrayBlockingQueue;

public class QueueClass {

	public static void main(String[] args) {
//		Queue<Integer> q = new ArrayBlockingQueue<Integer>(3);
//		try {
//		q.add(10);
//		q.add(20);
//		q.add(30);
//		q.add(40);
//		}catch(IllegalStateException e) {
//			e.printStackTrace();
//		}
//		for(Integer i:q)
//			System.out.println(i);
//		System.out.println(" ");
//		
//		System.out.println(q.remove());
		
		Queue<Integer> q1 = new ArrayBlockingQueue<Integer>(3);
			q1.offer(10);
			q1.offer(20);
			q1.offer(30);
			if(q1.offer(40)==false) {
				System.out.println("too many args");
			}

		for(Integer i:q1)
			System.out.println(i);
		System.out.println(" ");
		
		System.out.println(q1.poll());
		System.out.println(q1.poll());
		System.out.println(q1.poll());
		System.out.println(q1.poll());

	}

}
