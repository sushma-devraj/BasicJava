import java.util.ArrayList;
import java.util.List;

public class ArrayListClass {

	public static void main(String[] args) {
		//ArrayList<Integer> arr = new ArrayList<>();
		//or
		List<Integer> arr = new ArrayList<>();
		arr.add(10);
		arr.add(20);
		arr.add(30);
		arr.add(30);
		arr.add(5);
		
		for(int i=0; i<arr.size();i++) {
			System.out.println(arr.get(i));
		}
		
		//remove last element is fast
		//arr.remove(arr.size()-1);
		
		//remove first element but its slow
		//arr.remove(0);
		
//		System.out.println("After removal");
//		for(Integer a:arr)
//			System.out.println(a);

	}

}
