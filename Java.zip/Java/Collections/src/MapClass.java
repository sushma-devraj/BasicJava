import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

public class MapClass {
	public static void map(Map<Integer, String> map) {
		long start = System.currentTimeMillis();
		map.put(1, "one");
		map.put(1, "one");
		map.put(2, "two");
		map.put(3, "three");
		map.put(5, "five");
		map.put(6, "six");
		map.put(4, "four");

		for (Integer key : map.keySet())
			System.out.println(key + " " + map.get(key));
		long end = System.currentTimeMillis();
		System.out.print("map1 time: " );
		System.out.println(end - start);

	}

	public static void main(String[] args) {
		Map<Integer, String> hashmap = new HashMap<>();
		Map<Integer, String> linkedHashMap = new LinkedHashMap<>();
		Map<Integer, String> treeMap = new TreeMap<>();

		map(hashmap);
		map(linkedHashMap);
		map(treeMap);
	}

}
