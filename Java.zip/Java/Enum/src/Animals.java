
public enum Animals {
	CAT("Sonu"), DOG("Monu"), MOUSE("Mousy");
	
	String name;
	Animals(String name) {
		this.name=name;
	}
	public String getName() {
		return name;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Animal called "+ name;
	}

}
