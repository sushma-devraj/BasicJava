
public class App {

	public static void main(String[] args) {
		Animals animal = Animals.CAT;
		switch (animal) {
		case CAT:
			System.out.println("CAT");
			break;
		case DOG:
			System.out.println("DOG");
			break;
		}
		System.out.println(Animals.CAT);
		System.out.println(Animals.CAT.getClass());
		System.out.println(Animals.CAT.getName());
		System.out.println(Animals.DOG.name());
		
		Animals a = Animals.valueOf("CAT");
		System.out.println("toString: "+a.toString());

	}

}
