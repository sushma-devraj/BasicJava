
public class BasicEnum {
	public static final int CAT = 0;
	public static final int DOG = 1;

	public static void main(String[] args) {
		int animal = CAT;
		switch (animal) {
		case CAT:
			System.out.println(CAT);
			break;
		case DOG:
			System.out.println(DOG);
			break;
		default:
			System.out.println("Default");
		}
	}

}
