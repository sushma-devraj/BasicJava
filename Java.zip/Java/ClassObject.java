class Person {
	String name;
	int age;
}

public class ClassObject {

	public static void main(String[] args) {
		Person p1 = new Person();
		p1.name = "Joe";
		p1.age = 34;
		System.out.println("Name is: " + p1.name);
		System.out.println("Age is: " + p1.age);

	}

}
