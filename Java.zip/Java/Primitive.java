
public class Primitive {

	public static void main(String[] args) {
		byte b=1;
		short s=2;
		int i=4;
		long l=8;
		float f=4.0f;
		double d=8.0;
		char c='c';
		boolean bo=true;
		System.out.println(b+" "+s+" "+i+" "+i+" "+l+" "+f+" "+d+" "+c+" "+bo);

	}

}
