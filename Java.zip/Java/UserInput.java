import java.util.Scanner;

public class UserInput {

	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner input = new Scanner(System.in);
		System.out.println("Enter name: ");
		String name=input.nextLine();
		System.out.println("Enter age: ");
		int age=input.nextInt();
		System.out.println("Name is: "+name+" "+"Age is: "+age);

	}

}
