class Person6 {
	private String name;

	StringBuilder sb = new StringBuilder();
	String str;
	public void setName(String name) {
		this.name = name;
		this.name += "Niall";
		
		
		sb.append("Smitaaaaaaaa").append("            vvvvvv  ").append("Johnnnnn");
		
		str = sb.toString();
		
		System.out.println("Capacity: "+sb.capacity());
		System.out.println("Length: "+str.length());
	}

	public void getName() {
		
		System.out.println("Name: " + name);
		System.out.println("Name: " + sb.toString());
		System.out.println("Name: " + str);
		System.out.printf("Name: %10s\n",name);
	}
}

public class StringBuilder_Formatting {

	public static void main(String[] args) {
		Person6 p = new Person6();
		p.setName("Joe");
		p.getName();
		System.out.println(p);
	}

}
