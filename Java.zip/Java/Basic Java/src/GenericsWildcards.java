import java.util.ArrayList;

class Machine {
	static private int i=0;
	public String toString() {
		i++;
		return "Machine "+i;
	}

}

class Camera extends Machine {
	static private int i=0;
	public String toString() {
		i++;
		return "Camera "+i;
	}
}

public class GenericsWildcards {
	public static void showList(ArrayList<?> arr) {
		for (Object list : arr)
			System.out.println(list);

	}

	public static void main(String[] args) {
		ArrayList<Machine> arr = new ArrayList<>();
		arr.add(new Machine());
		arr.add(new Machine());
		
		ArrayList<Camera> arr1 = new ArrayList<>();
		arr1.add(new Camera());
		arr1.add(new Camera());

		showList(arr);


		showList(arr1);

	}
}
