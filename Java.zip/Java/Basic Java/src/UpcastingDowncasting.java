class Base {
	public void getMethod() {
		System.out.println("Base Method");
	}

}

class Child extends Base {
	public void getMethod() {
		System.out.println("Child Method1");
	}

	public void getChildMethod() {
		System.out.println("Child Method2");
	}
}

public class UpcastingDowncasting {

	public static void main(String[] args) {
		Base b = new Base();
		Child c = new Child();
		b.getMethod();
		c.getMethod();
		c.getChildMethod();
		
		//UpCasting
		System.out.println(" ");
		System.out.println("UpCasting");
		Base b1 = new Child();
		b1.getMethod();
		
		//DownCasting
		System.out.println(" ");
		System.out.println("DownCasting");
		Base b2 = new Child();
		Child c1 = (Child)b2;
		c1.getMethod();
		c1.getChildMethod();
		
		

	}

}
