class Person7 {
	public String toString() {
		//return "Hello World";
		
		StringBuffer sb = new StringBuffer();
		sb.append("Happy learning");
		return sb.toString();
	}
}

public class ToStringMethod{

	public static void main(String[] args) {
		Person7 p = new Person7();
		System.out.println(p);
	}

}
