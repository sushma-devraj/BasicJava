class Employee {
	private int id;
	private String name;

	public Employee(int id, String name) {
		this.id = id;
		this.name = name;
	}

	@Override
	public String toString() {
		return "Employee id= " + id + " " + "Employee name= " + name;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		if (id != other.id)
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}
}

public class EqualsMethod {

	public static void main(String[] args) {
		Employee emp1 = new Employee(1, "Sonu");
		Employee emp2 = new Employee(1, "Sonu");
		Employee emp3 = new Employee(2, "Tonu");
		Employee emp4 = new Employee(2, "Monu");
		if (emp1.equals(emp2)) {
			System.out.println("emp1 and emp2 are Equal");
		} else {
			System.out.println("emp1 and emp2 are Not equal");
		}

		if (emp3.equals(emp4)) {
			System.out.println("emp3 and emp4 are Equal");
		} else {
			System.out.println("emp3 and emp4 are Not equal");
		}
		
		Double d1=1.2;
		Double d2=1.2;
		System.out.println(d1.equals(d2));
		
		Integer i1=2;
		Integer i2=2;
		System.out.println(i1==i2); //always use .equals

		String str1="One";
		String str2="One";
		System.out.println(str1.equals(str2)); //Recommended for user defined type
		//System.out.println(str1==str2);
	}

}
