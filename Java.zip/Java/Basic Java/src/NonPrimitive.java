
public class NonPrimitive {

	public static void main(String[] args) {
		String str="Hello";
		System.out.println("String is: "+str);
	}

}
