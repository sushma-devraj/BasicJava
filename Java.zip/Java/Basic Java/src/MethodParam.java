class Person2{
	private String name1;
	private int age1;
	public void setName(String name){
		name1=name;
	}
	public void setAge(int age){
		age1=age;
	}
	public String getName(){
		return name1;
	}
	public int getAge(){
		return age1;
	}
}
public class MethodParam{
	public static void main(String[] args){
		Person2 p1 = new Person2();
		p1.setName("Joe");
		p1.setAge(29);
		System.out.println(p1.getName());
		System.out.println(p1.getAge());
	}
}