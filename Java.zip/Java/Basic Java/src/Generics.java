import java.util.ArrayList;

public class Generics {
	public static void main(String[] args) {
		
		////Old Style////
		ArrayList a = new ArrayList();
		a.add("one");
		a.add("two");

		String str1 = (String) a.get(0);
		String str2 = (String) a.get(1);
		System.out.println("String1: " + str1);
		System.out.println("String2: " + str2);
		
		
		////New Style/////
		ArrayList<String> a1 = new ArrayList<>();
		a1.add("One");
		a1.add("Two");
		
		
		System.out.println("String1: " + a1.get(0));
		System.out.println("String2: " + a1.get(1));
		
	}

}
