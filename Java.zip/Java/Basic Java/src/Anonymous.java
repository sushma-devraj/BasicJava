interface Plant {
	public void getGrow();
}

class Tree {
	public void getGrow() {
		System.out.println("Parent tree Growing");
	}
}

public class Anonymous {

	public static void main(String[] args) {
		Tree t = new Tree() {

			@Override
			public void getGrow() {
				System.out.println("Child tree Growing");
			}

		};
		t.getGrow();

		Plant p = new Plant() {

			@Override
			public void getGrow() {
				System.out.println("Plant Growing");
			}

		};
		p.getGrow();

	}

}
