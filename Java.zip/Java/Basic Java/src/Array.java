
public class Array {

	public static void main(String[] args) {
		int[] arr1=new int[3];
		for(int i=0; i<arr1.length; i++)
			arr1[i]=i+10;
		for(int i=0; i<arr1.length; i++)
			System.out.println("Value of arr "+i+" is: "+arr1[i]);

		int[] arr2={1,2,3};
		for(int i=0; i<arr2.length; i++)
			System.out.println("Value of arr "+i+" is: "+arr2[i]);

	}

}
