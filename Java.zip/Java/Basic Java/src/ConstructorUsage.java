class Person4{
	String name;
	int age;
	public Person4() {
		this("Joe",30);
		System.out.println("Inside first constructor");
	}
	
	public Person4(String name, int age) {
		System.out.println("Inside second constructor");
		this.name=name;
		this.age=age;
		System.out.println("name: "+name+" "+" age: "+age);
	}
}
public class ConstructorUsage {

	public static void main(String[] args) {
		new Person4();
		
	}

}
