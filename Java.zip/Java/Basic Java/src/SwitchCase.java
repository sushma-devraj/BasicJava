
public class SwitchCase {

	public static void main(String[] args) {
		String str="white";
		switch(str){
			case "red":
				System.out.println("Red Color");
				break;
			case "green":
				System.out.println("Green Color");
			case "white":
				System.out.println("White Color");
				break;
			default:
				System.out.println("Mixed Color");
				break;
		}

	}

}
