
public class IfCondition {

	public static void main(String[] args) {
		int i = 100;
		if(i<500){
			System.out.println("value is less than 500: "+i);		
		}else if(i>500){
			System.out.println("Value is greater than 500: "+i);
		}else{
			System.out.println("Value is equal to 500: "+i);
		}

	}

}
