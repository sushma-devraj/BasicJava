import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class WriteObject implements Serializable{

	public static void main(String[] args) {
		App app1 = new App(1,"one");
		App app2 = new App(2,"two");
		
		try(FileOutputStream fs = new FileOutputStream("Sample.txt")){
			ObjectOutputStream os = new ObjectOutputStream(fs);
			os.writeObject(app1);
			os.writeObject(app2);
			os.close();
		}
		catch(FileNotFoundException e) {
			e.printStackTrace();
			
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
