import java.io.FileNotFoundException;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;

public class ReadObject implements Serializable{

	public static void main(String[] args) {
		try(FileInputStream fi = new FileInputStream("Sample.txt")){
			ObjectInputStream os = new ObjectInputStream(fi);
			App app1 = (App)os.readObject();
			App app2 = (App)os.readObject();

			os.close();
			System.out.println(app1);
			System.out.println(app2);
		}
		catch(FileNotFoundException e) {
			e.printStackTrace();
			
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

	}

}
