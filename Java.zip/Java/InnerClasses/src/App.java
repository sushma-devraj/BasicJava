
public class App {

	public static void main(String[] args) {
		InnerClass IC = new InnerClass(10);
		IC.startInnerClass();
		
		//Ananonymous class
		InnerClass IC5=new InnerClass(10) {
			@Override
			public void startInnerClass() {
				System.out.println("Ananymous Inner class");
			}
		};
		IC5.startInnerClass();
		
		//public inner class object
		InnerClass.InnerClass1 II = new InnerClass(20).new InnerClass1();
		II.startInnerClass1();
		
		//static inner class
		InnerClass.InnerClass3 IC3 = new InnerClass.InnerClass3();
		IC3.startInnerClass3();
	}

}
