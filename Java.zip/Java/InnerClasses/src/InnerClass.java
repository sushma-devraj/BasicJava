
public class InnerClass {

	public static InnerClass3 InnerClass3;
	private int id;

	public InnerClass(int id) {
		this.id = id;
	}

	// public Class
	public class InnerClass1 {
		public void startInnerClass1() {
			System.out.println("startInnerClass1");
		}
	}

	// private Class
	private class InnerClass2 {
		public void startInnerClass2() {
			System.out.println("startInnerClass2");
		}
	}
	
	static class InnerClass3{
		public void startInnerClass3() {
			System.out.println("startInnerClass3");
		}
	}

	public void startInnerClass() {
		System.out.println("startInnerClass");
		InnerClass2 IC2 = new InnerClass2();
		IC2.startInnerClass2();
		
		class Temp{
			public void tempMethod() {
				System.out.println("Temp Method "+id);
			}
		}
		Temp temp = new Temp();
		temp.tempMethod();
	}

}
