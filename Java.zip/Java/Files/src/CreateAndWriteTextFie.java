import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class CreateAndWriteTextFie {
	public static void main(String[] args) {
		File file = new File("Example.txt");
		try(BufferedWriter bw = new BufferedWriter(new FileWriter(file))){
			bw.write("First Line");
			bw.newLine();
			bw.write("Second Line");
			bw.newLine();
			bw.write("Last Line");
		}
		catch(IOException e) {
			System.out.println(file.toString());
		}
		FileReader fr = null;
		BufferedReader br =null;
		try {
			fr = new FileReader(file);
			br =new BufferedReader(fr);
			String line;
			while((line=br.readLine())!=null) {
				System.out.println(line);
			}
		}
		catch(FileNotFoundException e) {
			System.out.println("FileNotFoundException");
		}
		catch(IOException e) {
			System.out.println("IOException");
		}
		
	}

}
