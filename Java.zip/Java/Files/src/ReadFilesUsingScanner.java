import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class ReadFilesUsingScanner {
	public static void main(String[] args) throws FileNotFoundException {
		// String filename = "C:\\Users\\sushma.devraj\\workspace\\files\\Text1.txt";

		String filename = "Example.txt";
		File file = new File(filename);

		Scanner sc = new Scanner(file);
		try {
			int value = sc.nextInt();
			System.out.println(value);
		} catch (Exception e) {
			System.out.println("Exception caught");
		} finally {
			sc.close();
		}
		int count = 0;
		while (sc.hasNextLine()) {
			String line = sc.nextLine();
			System.out.println(line);
			count++;
		}
		System.out.println("Count: " + count);

	}

}
