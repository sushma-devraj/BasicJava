
public class App {

	public static void main(String[] args) {
		Base b = new Base();
		b.getName();
		Child1 c= new Child1();
		c.getName();
		c.getChildName();
		
		Base b1 = new Child1();
		b1.getName();
	}

}
