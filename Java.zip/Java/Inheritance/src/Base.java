
public class Base {
	public void getName() {
		System.out.println("Base class");
	}
	

}
