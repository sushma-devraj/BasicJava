
public class Child1 extends Base {

	@Override
	public void getName() {
		// super.getName();
		System.out.println("Child class");
	}

	public void getChildName() {
		System.out.println("Child new name");
	}

}
