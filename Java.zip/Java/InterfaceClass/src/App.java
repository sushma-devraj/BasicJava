
public class App {

	public static void main(String[] args) {
		IVehicle vehicle = new Car();
		System.out.println("calling car print");
		vehicle.print();

	}

}
interface IVehicle{
	default void print() {
		System.out.println("Print Vehicle");
	}
}
interface IFourWheeler{
	static void print() {
		System.out.println("Print FourWheeler");
	}
}
class Car implements IVehicle, IFourWheeler{
	public void print() {
		IVehicle.super.print();
		IFourWheeler.print();
	}
}
