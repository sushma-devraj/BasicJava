
public interface InterfaceClass {
	default void printDefault() {
		System.out.println("default method");
	}
	
	static void printStatic() {
		System.out.println("static method");
	}

}
